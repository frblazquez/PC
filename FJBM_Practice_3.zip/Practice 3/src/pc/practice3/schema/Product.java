package pc.practice3.schema;

public interface Product {

    /**
     * @return String representation of the product.
     */
    public String getValueToString();
}
