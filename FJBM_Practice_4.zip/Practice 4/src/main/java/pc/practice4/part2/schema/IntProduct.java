package pc.practice4.part2.schema;

public class IntProduct implements Product {

    private int value;

    public IntProduct(int value) {
	this.value = value;
    }

    @Override
    public String toString() {
	return "" + value;
    }
}
