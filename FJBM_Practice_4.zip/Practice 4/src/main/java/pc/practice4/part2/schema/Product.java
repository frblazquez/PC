package pc.practice4.part2.schema;

public interface Product {

    /**
     * @return String representation of the product.
     */
    @Override
    public String toString();
}
